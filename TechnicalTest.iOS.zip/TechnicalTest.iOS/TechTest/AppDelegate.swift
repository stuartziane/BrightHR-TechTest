//
//  AppDelegate.swift
//  TechTest
//
//  Created by Alex Jackson on 01/03/2021.
//

import UIKit
import CoreData


final class AppDelegate: NSObject, UIApplicationDelegate, ObservableObject {
    
}
