//
//  PostComment.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation

struct PostComment: Codable, Identifiable, Hashable {
    
    let postId: Int
    let id: Int
    let name: String
    let email: String
    let body: String

}
