//
//  APIManager.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation
import Combine

protocol APIManagerService {
    func loadAllPosts() -> AnyPublisher<[Post], Error>
    func loadPost(id: Int) -> AnyPublisher<Post, Error>
    func loadCommentsForPostWith(id: Int) -> AnyPublisher<[PostComment], Error>
}

class APIManager: APIManagerService {
    
    let dataLoader: DataLoaderService
    
    init(dataLoader: DataLoaderService = URLSession.shared) {
        self.dataLoader = dataLoader
    }
    
    
    func loadAllPosts() -> AnyPublisher<[Post], Error> {
        
        guard let url = URL(string: APIUrl.getUrl(for: .allPosts)) else {
            let error = URLError(.badURL) as Error
            return Fail(error: error).eraseToAnyPublisher()
        }
        
        return dataLoader
            .load(URLRequest(url: url))
            .subscribe(on: DispatchQueue.global())
            .decode(type: [Post].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()

    }

    func loadPost(id: Int) -> AnyPublisher<Post, Error> {

        guard let url = URL(string: APIUrl.getUrl(for: .postWithId(id: id))) else {
            let error = URLError(.badURL) as Error
            return Fail(error: error).eraseToAnyPublisher()
        }
        
        return dataLoader
            .load(URLRequest(url: url))
            .subscribe(on: DispatchQueue.global())
            .decode(type: Post.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }

    func loadCommentsForPostWith(id: Int) -> AnyPublisher<[PostComment], Error> {
        
        guard let url = URL(string: APIUrl.getUrl(for: .commentsForPost(id: id))) else {
            let error = URLError(.badURL) as Error
            return Fail(error: error).eraseToAnyPublisher()
        }
        
        return dataLoader
            .load(URLRequest(url: url))
            .subscribe(on: DispatchQueue.global())
            .decode(type: [PostComment].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()

    }
    
    
}
