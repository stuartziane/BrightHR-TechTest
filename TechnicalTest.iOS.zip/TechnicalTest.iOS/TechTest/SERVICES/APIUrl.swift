//
//  APIUrl.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation

enum APIUrl {
    
    case allPosts
    case postWithId(id: Int)
    case commentsForPost(id: Int)
    
    static func getUrl(for apiUrl: APIUrl) -> String {
        
        switch apiUrl {
            case .allPosts:
                return "https://jsonplaceholder.typicode.com/posts/"
                
            case .postWithId(let id):
                return "https://jsonplaceholder.typicode.com/posts/\(id)/"
                
            case .commentsForPost(let id):
                return "https://jsonplaceholder.typicode.com/posts/\(id)/comments/"
        }
        
    }
}
