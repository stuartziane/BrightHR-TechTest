//
//  OfflineDataService.swift
//  TechTest
//
//  Created by Stuart Ziane on 10/01/2023.
//

import Foundation
import SwiftUI

enum DataServiceError: Error {
    case encodingError
    case decodingError
    case errorCreatingJSONString
    case errorConvertingStringToData
    case urlError
    case documentStorageDirectoryError
    case errorLoadingOfflinePosts
}

enum OfflineStorageDirectory: String {
    
    case documentsDirectory = "offline-storage"
}

protocol OfflineDataService {
    
    func storePostsOffline(offlinePosts: [Post], completion: (Result<Bool, DataServiceError>) -> Void)
    
    func loadOfflinePosts(completion: (Result<[Post], DataServiceError>) -> Void)
}

class OfflineDataManager: OfflineDataService {
    
    let manager = FileManager.default
    
    func storePostsOffline(offlinePosts: [Post], completion: (Result<Bool, DataServiceError>) -> Void) {
        
        let encoder = JSONEncoder()
        guard let data = try? encoder.encode(offlinePosts) else {
            
            return completion(.failure(.encodingError))
        }
        
        do {
            let url = getDocumentsDirectory().appendingPathComponent(OfflineStorageDirectory.documentsDirectory.rawValue)
            try data.write(to: url, options: [.atomicWrite, .completeFileProtection])
            
        } catch {
            completion(.failure(.urlError))
        }
        
        completion(.success(true))
    }
    
    func loadOfflinePosts(completion: (Result<[Post], DataServiceError>) -> Void) {
        
        do {
            let url = getDocumentsDirectory().appendingPathComponent(OfflineStorageDirectory.documentsDirectory.rawValue)
            let data = try Data(contentsOf: url)
            let loadedPosts = try JSONDecoder().decode([Post].self, from: data)
            completion(.success(loadedPosts))
        } catch {
            completion(.failure(.errorLoadingOfflinePosts))
        }
    }
    
    private func getDocumentsDirectory() -> URL {
        return manager.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
}
