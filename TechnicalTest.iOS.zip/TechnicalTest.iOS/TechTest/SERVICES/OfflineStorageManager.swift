//
//  OfflineStorageManager.swift
//  TechTest
//
//  Created by Stuart Ziane on 10/01/2023.
//

import Foundation
import SwiftUI
import Combine

enum CustomCodableError: Error {
    
    case unableToLoadData
    case unableToDecode
}

protocol OfflineStorageService {
    
    func storePostsOffline(offlinePosts: [Post])
    func loadOfflinePosts(completion: (Result<[Post], Error>) -> Void)
}

class OfflineStorageManager: OfflineStorageService {
    
    @AppStorage("offlinePostStorage") var offlinePostStorage = ""
    
    func storePostsOffline(offlinePosts: [Post]) {
        
        let encoder = JSONEncoder()
        guard let data = try? encoder.encode(offlinePosts) else { return }
        guard let string = String(data: data, encoding: .utf8) else { return }
        
        offlinePostStorage = string
    }
    
    func loadOfflinePosts(completion: (Result<[Post], Error>) -> Void) {
        
        let decoder = JSONDecoder()
        guard let data = offlinePostStorage.data(using: .utf8) else {
            completion(.failure(CustomCodableError.unableToLoadData))
            return
        }
        
        guard let posts = try? decoder.decode([Post].self, from: data) else {
            completion(.failure(CustomCodableError.unableToDecode))
            return
        }
        
        completion(.success(posts))
    }
}
