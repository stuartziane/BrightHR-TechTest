//
//  URLSession+DataLoaderService.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation

import Foundation
import Combine

protocol DataLoaderService {
    func load(_ request: URLRequest) -> AnyPublisher<Data, URLError>
}

extension URLSession: DataLoaderService {
    
    func load(_ request: URLRequest) -> AnyPublisher<Data, URLError> {
        return dataTaskPublisher(for: request)
            .map(\.data)
            .eraseToAnyPublisher()
    }
    
}
