//
//  TechTestApp.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

@main
struct TechTestApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    @Environment(\.scenePhase) private var scenePhase
    
    @StateObject var viewModel = ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager())
    
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: viewModel)
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                self.viewModel.loadAllPosts()
                self.viewModel.loadOfflinePosts()
            }
        }
    }
}
