//
//  ViewModel.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation
import Combine
import UIKit
import CoreData
import SwiftUI

enum AppState {
    case isLoading
    case loaded
}

class ViewModel: ObservableObject {
    
    let apiManager: APIManagerService
    
    let offlineDataManager: OfflineDataService
    
    init(apiManager: APIManagerService, offlineDataManager: OfflineDataService) {
        self.apiManager = apiManager
        self.offlineDataManager = offlineDataManager
    }
    
    @Published var posts = [Post]()
    @Published var offlinePosts = [Post]()
    @Published var comments = [PostComment]()
    
    @Published var alertShowing = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""
    
    @Published var isLoading: AppState = .isLoading
    
    @Published var showCommentsView = false
    
    var cancellables = Set<AnyCancellable>()
    
    func loadAllPosts() {
        
        self.isLoading = .isLoading
        apiManager
            .loadAllPosts()
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        print("Loaded posts successfully")
                    case.failure(let error):
                        print("Failed with error: \(error)")
                }
            } receiveValue: { [weak self] loadedPosts in
                self?.isLoading = .loaded
                self?.posts = loadedPosts
            }
            .store(in: &cancellables)
    }
    
    func loadCommentsForPost(with id: Int) {
        
        self.isLoading = .isLoading
        
        apiManager
            .loadCommentsForPostWith(id: id)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        print("Loaded post comments for post id \(id) successfully")
                    case.failure(let error):
                        print("Failed with error: \(error)")
                }
            } receiveValue: { [weak self] loadedComments in
                self?.isLoading = .loaded
                self?.comments = loadedComments
            }
            .store(in: &cancellables)
    }
    
    // MARK: Methods for dealing with offline posts
    
    func storePostsOffline() {
        
        offlineDataManager.storePostsOffline(offlinePosts: offlinePosts) { [weak self] completion in
            switch completion {
                case .success:
                    return
                case .failure:
                    self?.alertTitle = "An error occurred!"
                    self?.alertMessage = "There was a problem storing this quote offline"
                    self?.alertShowing = true
            }
        }
    }
    
    func loadOfflinePosts() {
        
        offlineDataManager.loadOfflinePosts { [weak self] result in
            
            switch result {
                case .success(let posts):
                    self?.offlinePosts = posts
                    
                case .failure:
                    self?.alertTitle = "An error occurred!"
                    self?.alertMessage = "There was a problem retrieving the offline quotes"
                    self?.alertShowing = true            }
        }
    }
    
    func storePostOffline(post: Post) {
        if !isStoredOffline(post: post) {
            offlinePosts.append(post)
            storePostsOffline()
        } else {
            return
        }
    }
    
    func removeOfflinePost(post: Post) {
        offlinePosts.removeAll(where: { $0.id == post.id })
        storePostsOffline()
    }
    
    func isStoredOffline(post: Post) -> Bool {
        
        if offlinePosts.contains(post) {
            return true
        }
        
        return false
    }
    
    func handleOfflineStatus(post: Post) {
        
        if !offlinePosts.contains(post) {
            storePostOffline(post: post)
        } else {
            removeOfflinePost(post: post)
        }
    }
    

}
