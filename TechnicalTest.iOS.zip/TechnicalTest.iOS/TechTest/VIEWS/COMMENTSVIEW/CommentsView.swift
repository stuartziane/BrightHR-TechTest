//
//  CommentsView.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

struct CommentsView: View {
    
    let post: Post
    
    @ObservedObject var viewModel: ViewModel
    
    init(post: Post, viewModel: ViewModel) {
        self.post = post
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        VStack {
            ContentHeaderView(title: "Comments") {
                Image(systemName: "xmark.circle")
                    .resizable()
                    .frame(width: 25, height: 25)
                    .foregroundColor(.blue)
                    .onTapGesture {
                        viewModel.showCommentsView = false
                    }
            }
            .padding(20)
            
            switch viewModel.isLoading {
                case .isLoading:
                    ProgressView()
                case .loaded:
                    ScrollView {
                        VStack(alignment: .leading) {
                            ForEach(viewModel.comments) { comment in
                                VStack(alignment: .leading) {
                                    Text(comment.name)
                                        .font(.headline)
                                        .padding(.bottom, 10)
                                        .multilineTextAlignment(.leading)
                                    Text(comment.body)
                                        .multilineTextAlignment(.leading)
                                        .padding(.bottom, 10)
                                    
                                    Divider()
                                }
                            }
                        }
                        .padding(20)
                    }
                    .navigationTitle("Comments")
            }
        }
        .onAppear {
            viewModel.loadCommentsForPost(with: post.id)
        }
        .alert(isPresented: $viewModel.alertShowing) {
            Alert(title: Text(viewModel.alertTitle),
                  message: Text(viewModel.alertMessage),
                  dismissButton: .default(Text("OK")))
        }
    }
}

struct CommentsView_Previews: PreviewProvider {
    static var previews: some View {
        CommentsView(post: Post(id: 1, title: "A title", body: "A body"), viewModel: ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager()))
    }
}
