//
//  ContentHeaderView.swift
//  TechTest
//
//  Created by Stuart Ziane on 12/01/2023.
//

import SwiftUI

struct ContentHeaderView<Content: View>: View {
    
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.title)
                .fontWeight(.bold)
            
            Spacer()
            
            content
        }
    }
}

struct ContentHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        ContentHeaderView(title: "Hello") {
            Text("It's Stuart")
        }
    }
}
