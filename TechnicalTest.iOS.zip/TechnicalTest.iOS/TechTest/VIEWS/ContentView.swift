//
//  ContentView.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var viewModel: ViewModel
    
    init(viewModel: ViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        
            TabView {
                ListView(viewModel: viewModel)
                    .tabItem {
                        Label("Quotes", systemImage: "quote.bubble")
                        
                    }
                
                OfflineListView(viewModel: viewModel)
                    .tabItem {
                        Label("Saved", systemImage: "\(viewModel.offlinePosts.count).circle.fill")
                    }
                
            }
            .alert(isPresented: $viewModel.alertShowing) {
                Alert(title: Text(viewModel.alertTitle),
                      message: Text(viewModel.alertMessage),
                      dismissButton: .default(Text("OK")))
            }
            
        
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(viewModel: ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager()))
    }
}
