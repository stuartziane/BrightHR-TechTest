//
//  OfflineDetailView.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

struct OfflineDetailView: View {
    
    let post: Post
    
    @ObservedObject var viewModel: ViewModel
    
    init(post: Post, viewModel: ViewModel) {
        self.post = post
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    var body: some View {
        
        VStack {
            Text(post.title)
                .font(.title)
            
            Spacer()
            
            Text(post.body)
                .font(.headline.italic())
                .fontWeight(.regular)
            
            Spacer()
            
        }
        .padding()
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Image(systemName: "bookmark.fill")
                    .resizable()
                    .frame(width: 20, height: 25)
                    .foregroundColor(.red)
                    .onTapGesture {
                        viewModel.handleOfflineStatus(post: post)
                    }
            }
        }
        .alert(isPresented: $viewModel.alertShowing) {
            Alert(title: Text(viewModel.alertTitle),
                  message: Text(viewModel.alertMessage),
                  dismissButton: .default(Text("OK")))
        }
    }
}

struct OfflineDetailView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        OfflineDetailView(post: Post(id: 1, title: "Test", body: "Test"), viewModel: ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager()))
    }
}
