//
//  ListView.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

struct ListView: View {
    
    @ObservedObject var viewModel: ViewModel

    
    init(viewModel: ViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        NavigationView {
            
            switch viewModel.isLoading {
                case .isLoading:
                    ProgressView()
                case .loaded:
                    List {
                        ForEach(viewModel.posts) { post in
                            NavigationLink {
                                DetailView(post: post, viewModel: viewModel)
                            } label: {
                                VStack(alignment: .leading) {
                                    Text(post.title)
                                        .font(.headline)
                                        .padding(.bottom, 10)
                                    Text(post.body)
                                }
                            }
                            .frame(height: 120)
                            
                        }
                        .listStyle(.plain)
                    }
                    .navigationTitle("Quotes")
            }
        }
        .alert(isPresented: $viewModel.alertShowing) {
            Alert(title: Text(viewModel.alertTitle),
                  message: Text(viewModel.alertMessage),
                  dismissButton: .default(Text("OK")))
        }
        
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView(viewModel: ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager()))
    }
}
