//
//  OfflineListView.swift
//  TechTest
//
//  Created by Stuart Ziane on 09/01/2023.
//

import SwiftUI

struct OfflineListView: View {
    
    @ObservedObject var viewModel: ViewModel
    
    init(viewModel: ViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.offlinePosts.count == 0 {
                    Text("You can store quotes to view them offline by tapping on the bookmark button")
                        .fontWeight(.light)
                        .padding(20)
                        .multilineTextAlignment(.center)
                } else {
                    List {
                        ForEach(viewModel.offlinePosts) { post in
                            NavigationLink {
                                OfflineDetailView(post: post, viewModel: viewModel)
                            } label: {
                                VStack(alignment: .leading) {
                                    Text(post.title)
                                        .font(.headline)
                                        .padding(.bottom, 10)
                                    Text(post.body)
                                }
                            }
                            .frame(height: 120)
                            
                        }
                    }
                }
            }
            .navigationTitle("Stored Quotes")
            .alert(isPresented: $viewModel.alertShowing) {
                Alert(title: Text(viewModel.alertTitle),
                      message: Text(viewModel.alertMessage),
                      dismissButton: .default(Text("OK")))
            }
        }
    }
}

struct StoredListView_Previews: PreviewProvider {
    static var previews: some View {
        OfflineListView(viewModel: ViewModel(apiManager: APIManager(), offlineDataManager: OfflineDataManager()))
    }
}
