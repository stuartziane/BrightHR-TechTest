//
//  TabBarItemView.swift
//  TechTest
//
//  Created by Stuart Ziane on 10/01/2023.
//

import SwiftUI

struct TabBarItemView: View {
    
    let count: Int
    
    var body: some View {
        
        VStack {
            Image(systemName: "\(count).circle.fill")
            Text("Offline")
        }
    }
}

struct TabBarItemView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarItemView(count: 5)
    }
}
