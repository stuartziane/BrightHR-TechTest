//
//  APIManagerTests.swift
//  TechTestTests
//
//  Created by Stuart Ziane on 09/01/2023.
//

import XCTest
import Combine
@testable import TechTest

final class APIManagerTests: XCTestCase {

    let apiManager: APIManagerService = APIManager()
    
    var cancellables = Set<AnyCancellable>()
    
    
    // Tests the `dataFromJSONFile` method to ensure it returns valid data from the JSON file
    func test_DecodesFromJSONData() throws {
        let data = try dataFromJSONFile(named: "PostByID")
        
        let post = try JSONDecoder().decode(Post.self, from: data)
        
        XCTAssertEqual(post.id, 1)
        XCTAssertEqual(post.title, "sunt aut facere repellat provident occaecati excepturi optio reprehenderit")
        XCTAssertEqual(post.body, "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto")
    }
    
    
    // MARK: Tests for success
    
    
    func test_apiManager_loadAllPosts_returnsResults_IfSuccessful() throws {
        
        let data = try dataFromJSONFile(named: "Posts")
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .success(data)))
        
        let resultExp = expectation(description: "Publishes list of posts")
        let completionExp = expectation(description: "Completes publishing a list of posts")
        
        apiManager
            .loadAllPosts()
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        completionExp.fulfill()
                    case.failure(let error):
                        XCTFail("Expected to succeed, but failed with error: \(error)")
                }
            } receiveValue: { posts in
                XCTAssertEqual(posts.count, 100)
                resultExp.fulfill()
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1)
    }
    
    
    func test_apiManager_loadPostById_returnsResult_IfSuccessful() throws {
        
        let data = try dataFromJSONFile(named: "PostByID")
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .success(data)))
        
        let resultExp = expectation(description: "Publishes list of posts")
        let completionExp = expectation(description: "Completes publishing a list of posts")
        
        apiManager
            .loadPost(id: 1)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        completionExp.fulfill()
                    case.failure(let error):
                        XCTFail("Expected to succeed, but failed with error: \(error)")
                }
            } receiveValue: { post in
                XCTAssertEqual(post.id, 1)
                resultExp.fulfill()
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1)
        
    }
    
    func test_apiManager_loadAllCommentsForPostById_returnsResults_IfSuccessful() throws {
        
        let data = try dataFromJSONFile(named: "Comments")
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .success(data)))
        
        let resultExp = expectation(description: "Publishes list of posts")
        let completionExp = expectation(description: "Completes publishing a list of posts")
        
        apiManager
            .loadCommentsForPostWith(id: 1)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        completionExp.fulfill()
                    case.failure(let error):
                        XCTFail("Expected to succeed, but failed with error: \(error)")
                }
            } receiveValue: { comments in
                XCTAssertEqual(comments.count, 5)
                resultExp.fulfill()
            }
            .store(in: &cancellables)
        
        
        waitForExpectations(timeout: 1)
        
    }
    
    // MARK: Tests for failure
    
    
    func test_apiManager_loadAllPosts_returnsError_IfUnsuccessful() throws {
        
        let expectedError = URLError(.badServerResponse)
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .failure(expectedError)))
        
        let exp = expectation(description: "Publishes a URLError")
        
        apiManager
            .loadAllPosts()
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        XCTFail("Expected to fail, but finished with success")
                    case.failure(let error):
                        print(error.localizedDescription)
                        exp.fulfill()
                }
            } receiveValue: { posts in
                XCTFail("Expected to fail, but succeeded with \(posts.count) posts")
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1)
        
    }
    
    
    func test_apiManager_loadPostById_returnsError_IfUnsuccessful() throws {
        
        let expectedError = URLError(.badServerResponse)
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .failure(expectedError)))
        
        let exp = expectation(description: "Publishes a URL error when loading post with specified ID fails")
        
        let id = 1
        
        apiManager
            .loadPost(id: id)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        XCTFail("Expected to fail, but finished with success")
                    case .failure(let error):
                        print(error)
                        exp.fulfill()
                }
            } receiveValue: { post in
                XCTFail("Expected to fail, but succeeded with loading a post")
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1)
        
    }
    
    func test_apiManager_loadAllCommentsForPostById_returnsError_IfUnsuccessful() throws {
        
        let expectedError = URLError(.badServerResponse)
        
        let apiManager = APIManager(dataLoader: DataLoaderStub(returning: .failure(expectedError)))
        
        let exp = expectation(description: "Publishes list of posts")
        
        let id = 1
        
        apiManager
            .loadCommentsForPostWith(id: id)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                    case .finished:
                        XCTFail("Expected to fail, but finished with success")
                    case .failure(let error):
                        print(error)
                        exp.fulfill()
                }
            } receiveValue: { comments in
                XCTFail("Expected to fail, but succeeded with loading \(comments.count) comments for a post")
            }
            .store(in: &cancellables)
        
        
        waitForExpectations(timeout: 1)
        
    }

}
