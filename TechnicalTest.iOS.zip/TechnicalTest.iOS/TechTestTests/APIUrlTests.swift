//
//  APIUrlTests.swift
//  TechTestTests
//
//  Created by Stuart Ziane on 09/01/2023.
//

import XCTest
@testable import TechTest

final class APIUrlTests: XCTestCase {

    // MARK: Tests for success when valid parameter passed to `getURL` method
    
    func test_APIUrl_returnsValidUrl_allPosts() throws {
        
        let type: APIUrl = .allPosts
        
        let result = APIUrl.getUrl(for: type)
        
        XCTAssertEqual(result, "https://jsonplaceholder.typicode.com/posts/")
        XCTAssertNotEqual(result, "https://jsonplaceholder.typicode.com/posts")
    }
    
    func test_APIUrl_returnsValidUrl_postById() throws {
        
        let id = 1
        
        let type: APIUrl = .postWithId(id: id)
        
        let result = APIUrl.getUrl(for: type)
        
        XCTAssertEqual(result, "https://jsonplaceholder.typicode.com/posts/1/")
        XCTAssertNotEqual(result, "https://jsonplaceholder.typicode.com/posts/1")
    }
    
    func test_APIUrl_returnsValidUrl_allCommentsForPostWithId() throws {
        
        let id = 1
        
        let type: APIUrl = .commentsForPost(id: id)
        
        let result = APIUrl.getUrl(for: type)
        
        XCTAssertEqual(result, "https://jsonplaceholder.typicode.com/posts/1/comments/")
        XCTAssertNotEqual(result, "https://jsonplaceholder.typicode.com/posts/1/comments")
        
    }

}
