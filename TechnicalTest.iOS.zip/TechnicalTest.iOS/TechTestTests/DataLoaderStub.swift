//
//  DataLoaderStub.swift
//  TechTestTests
//
//  Created by Stuart Ziane on 09/01/2023.
//

@testable import TechTest
import Combine
import Foundation

class DataLoaderStub: DataLoaderService {
    
    private let result: Result<Data, URLError>
    
    init(returning result: Result<Data, URLError>) {
        self.result = result
    }
    
    
    func load(_ request: URLRequest) -> AnyPublisher<Data, URLError> {
        
        return result.publisher
            .delay(for: 0.01, scheduler: RunLoop.main)
            .eraseToAnyPublisher()
    }
}
