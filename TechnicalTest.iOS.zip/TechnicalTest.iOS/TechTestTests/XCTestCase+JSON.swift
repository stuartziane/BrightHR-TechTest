//
//  XCTestCase+JSON.swift
//  TechTestTests
//
//  Created by Stuart Ziane on 09/01/2023.
//

import Foundation
import XCTest


extension XCTestCase {
    
    /// Loads a JSON file from the Bundle and returns the data
    ///
    func dataFromJSONFile(named name: String) throws -> Data {
        
        let url = try XCTUnwrap(
            Bundle(for: type(of: self)).url(forResource: name,
                                            withExtension: "json")
        )
        
        return try Data(contentsOf: url)
        
    }
}
